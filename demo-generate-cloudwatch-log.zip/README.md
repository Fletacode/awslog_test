1. node 18이상 설치
2. yarn 설치 (or npm 사용)
```
npm install -g yarn
```
3. 의존모듈 설치 
```
yarn
```
4. AWS IAM 사용자 생성(CloudWatch Full Access)
5. 소스코드에 AccessKey Pair 입력
실행