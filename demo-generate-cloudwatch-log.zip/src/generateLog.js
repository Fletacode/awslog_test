// Import required AWS SDK clients and commands for Node.js
const { CloudWatchLogsClient, CreateLogGroupCommand, CreateLogStreamCommand, PutLogEventsCommand } = require("@aws-sdk/client-cloudwatch-logs");

// AWS credentials
const accessKeyId = "accessKeyId";
const secretAccessKey = "secretAccessKey";

// Set up AWS SDK client with credentials
const client = new CloudWatchLogsClient({
    region: "ap-northeast-2",
    credentials: {
        accessKeyId,
        secretAccessKey
    }
});

// Function to generate artificial web log data
const generateLogData = () => {
    const logs = [];
    const logLevels = ["INFO", "WARN", "ERROR"];
    const userIds = ["bob", "alice", "chris", "david", "eve"];
    const urls = ["/home", "/about", "/contact", "/login", "/signup"];
    const userAgents = ["Mozilla/5.0", "Chrome/91.0", "Safari/537.36"];
    const httpStatusCodes = [200, 201, 204, 400, 401, 403, 404, 500, 502, 503];

    for (let i = 0; i < 100; i++) {
        const log = {
            timestamp: new Date().toISOString(),
            level: logLevels[Math.floor(Math.random() * logLevels.length)],
            userId: userIds[Math.floor(Math.random() * userIds.length)],
            url: urls[Math.floor(Math.random() * urls.length)],
            userAgent: userAgents[Math.floor(Math.random() * userAgents.length)],
            httpStatusCode: httpStatusCodes[Math.floor(Math.random() * httpStatusCodes.length)],
            message: `Log message ${i}`
        };
        logs.push(log);
    }
    return logs;
};

// Function to upload logs to CloudWatch
const uploadLogs = async (logGroupName, logStreamName, logs) => {
    try {
        // Create log group if it doesn't exist
        try {
            await client.send(new CreateLogGroupCommand({ logGroupName }));
        } catch (error) {
            if (error.name !== "ResourceAlreadyExistsException") {
                throw error;
            }
        }


        // Create log stream
        try {
            await client.send(new CreateLogStreamCommand({ logGroupName, logStreamName }));
        }
        catch (error) {
            if (error.name !== "ResourceAlreadyExistsException") {
                throw error;
            }
        }
        // Prepare log events
        const logEvents = logs.map((log, index) => ({
            timestamp: new Date(log.timestamp).getTime(),
            message: JSON.stringify(log)
        }));

        // Upload log events
        await client.send(new PutLogEventsCommand({
            logGroupName,
            logStreamName,
            logEvents
        }));

        console.log(`Logs uploaded to ${logGroupName}/${logStreamName}`);
    } catch (error) {
        console.error("Error uploading logs:", error);
    }
};

// Main function to generate and upload logs
const main = async () => {
    const logGroupName = "my-log-group";
    const logStreams = ["log-stream-1", "log-stream-2", "log-stream-3"];

    for (const logStreamName of logStreams) {
        const logs = generateLogData();
        await uploadLogs(logGroupName, logStreamName, logs);
    }
};

main();